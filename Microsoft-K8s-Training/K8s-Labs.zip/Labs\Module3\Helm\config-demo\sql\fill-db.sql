USE sample2;
INSERT INTO friends2 VALUES (1, 'John Smith', 32, 'm');
INSERT INTO friends2 VALUES (2, 'Lilian Worksmith', 29, 'f');
INSERT INTO friends2 VALUES (3, 'Michael Rupert', 27, 'm');

