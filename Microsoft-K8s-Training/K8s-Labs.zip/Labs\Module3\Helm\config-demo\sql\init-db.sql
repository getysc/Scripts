CREATE DATABASE sample2;
USE sample2;
CREATE TABLE friends2 (id INT, name VARCHAR(256), age INT, gender VARCHAR(3));